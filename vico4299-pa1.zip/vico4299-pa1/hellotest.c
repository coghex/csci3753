#include<unistd.h>
#include<sys/syscall.h>

int main () {
  syscall(314);
  return 0;
}
